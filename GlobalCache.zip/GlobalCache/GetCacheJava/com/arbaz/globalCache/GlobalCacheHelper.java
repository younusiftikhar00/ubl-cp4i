package com.arbaz.globalCache;

//import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbGlobalMap;

public class GlobalCacheHelper {

	public static void insertInCache(String cacheName, String key, String value) {
	    try {
	      MbGlobalMap map = MbGlobalMap.getGlobalMap(cacheName);
	      String test = (String)map.get(key);
	      if (test == null) {
	        map.put(key, value);
	      } else {
	        map.update(key, value);
	      } 
	    } catch (MbException e) {
	      throw new CacheFailureException(cacheName, "Insert Entry", e);
	    } 
	}
	public static String readFromCache(String cacheName, String key) {
	    try {
	      MbGlobalMap map = MbGlobalMap.getGlobalMap(cacheName);
	      return (String)map.get(key);
	    } catch (MbException e) {
	      throw new CacheFailureException(cacheName, "Read Entry", e);
	    } 
	}
	

}
